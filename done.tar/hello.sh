#!/bin/bash
echo "Hello egathang!"
